from django.urls import path
from . import views

urlpatterns = [
    path('get/',views.Get_view),
    path('',views.home_view,name='home'),

]