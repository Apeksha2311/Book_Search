from django.shortcuts import render
from rest_framework.decorators import api_view
from .models import BookModel
from .serializers import BookSerializer

from rest_framework.response import Response

# Create your views here.

@api_view(['GET'])
def Get_view(request):
    books = BookModel.objects.all()

    price = request.GET.get('price')    #get price value
    #print(price)
    if price:
        books = books.filter(price__lte = price)

    name = request.GET.get('name')  #get book name value
    if name:
        books = books.filter(name__contains = name)

    serializer = BookSerializer(books ,many = True)

    if serializer.data:
        return Response(serializer.data)
    return Response({'msg':'No Data found'})    